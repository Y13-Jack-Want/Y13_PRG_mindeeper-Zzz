How to play BOMBWIPER:
- To play BOMBWIPER you must first run the program using python
- Once you have launcheed the game you will be met with a difficulty select screen
  you simply type the name of the difficulty (Case sensitive) and press enter to
  select that difficulty
- The game will then generate the board this is where the actual game begins
- You start off by clicking a random square on the grid
- This will then display a number on the square
- This number displays how many bombs that square touches with the 8 adjacent squares
- The goal of the game is to clear(click) on every square that doesn't contain a bomb
  Succesfully clearing the bombfield

P.S. I wouldn't advise choosing the "!!!IMPOSSIBLE!!!" difficulty as it can freeze your 
     computer dueee to tkinter not being particularly optimised.
